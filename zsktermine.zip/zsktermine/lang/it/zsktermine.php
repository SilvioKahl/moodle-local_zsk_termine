<?php

// This file is part of Moodle - http://moodle.org/



defined('MOODLE_INTERNAL') || die();



$string['modulename'] = 'Eventi del corso ZSK';
$string['modulenameplural'] = 'Eventi del corso ZSK';
$string['pluginname'] = 'Eventi del corso ZSK';
$string['modulename_help'] = 'Mostra i prossimi eventi assegnati a questo corso nel gestore eventi centrale. Gli eventi a livello di sito (nessun corso) non vengono mostrati qui.';
$string['zsktermine:addinstance'] = 'Aggiungi un\'attività "Eventi del corso ZSK".';
$string['zsktermine:view'] = 'Visualizza gli eventi del corso';
$string['courseevents_info'] = 'Gli eventi assegnati a questo corso vengono visualizzati direttamente nella pagina del corso sotto l\'attività (non è richiesto alcun clic). Facoltativamente puoi anche mostrare un\'introduzione.';
$string['upcoming_for_course'] = 'Prossimi eventi per questo corso';
$string['no_course_events'] = 'Non ci sono eventi imminenti assegnati a questo corso.';
