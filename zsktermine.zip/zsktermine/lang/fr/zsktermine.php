<?php

// This file is part of Moodle - http://moodle.org/



defined('MOODLE_INTERNAL') || die();



$string['modulename'] = 'Événements des cours ZSK';
$string['modulenameplural'] = 'Événements des cours ZSK';
$string['pluginname'] = 'Événements des cours ZSK';
$string['modulename_help'] = 'Affiche les événements à venir attribués à ce cours dans le gestionnaire central d\'événements. Les événements à l\'échelle du site (pas de cours) ne sont pas affichés ici.';
$string['zsktermine:addinstance'] = 'Ajouter une activité « Événements de cours ZSK »';
$string['zsktermine:view'] = 'Voir les événements du cours';
$string['courseevents_info'] = 'Les événements attribués à ce cours sont affichés directement sur la page du cours sous l\'activité (aucun clic requis). Vous pouvez éventuellement afficher une introduction.';
$string['upcoming_for_course'] = 'Événements à venir pour ce cours';
$string['no_course_events'] = 'Il n\'y a aucun événement à venir attribué à ce cours.';
