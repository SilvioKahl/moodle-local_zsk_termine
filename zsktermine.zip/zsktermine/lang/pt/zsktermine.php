<?php

// This file is part of Moodle - http://moodle.org/



defined('MOODLE_INTERNAL') || die();



$string['modulename'] = 'Eventos do curso ZSK';
$string['modulenameplural'] = 'Eventos do curso ZSK';
$string['pluginname'] = 'Eventos do curso ZSK';
$string['modulename_help'] = 'Mostra os próximos eventos atribuídos a este curso no gerenciador central de eventos. Eventos em todo o site (sem curso) não são mostrados aqui.';
$string['zsktermine:addinstance'] = 'Adicione uma atividade “Eventos de curso ZSK”';
$string['zsktermine:view'] = 'Ver eventos do curso';
$string['courseevents_info'] = 'Os eventos atribuídos a este curso são mostrados diretamente na página do curso abaixo da atividade (não é necessário clicar). Opcionalmente, você também pode mostrar uma introdução.';
$string['upcoming_for_course'] = 'Próximos eventos deste curso';
$string['no_course_events'] = 'Não há eventos futuros atribuídos a este curso.';
