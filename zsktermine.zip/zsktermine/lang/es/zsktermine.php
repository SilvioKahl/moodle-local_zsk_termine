<?php

// This file is part of Moodle - http://moodle.org/



defined('MOODLE_INTERNAL') || die();



$string['modulename'] = 'Eventos del curso ZSK';
$string['modulenameplural'] = 'Eventos del curso ZSK';
$string['pluginname'] = 'Eventos del curso ZSK';
$string['modulename_help'] = 'Muestra los próximos eventos asignados a este curso en el administrador de eventos central. Los eventos de todo el sitio (sin curso) no se muestran aquí.';
$string['zsktermine:addinstance'] = 'Agregar una actividad de “eventos del curso ZSK”';
$string['zsktermine:view'] = 'Ver eventos del curso';
$string['courseevents_info'] = 'Los eventos asignados a este curso se muestran directamente en la página del curso debajo de la actividad (no es necesario hacer clic). Opcionalmente, también puedes mostrar una introducción.';
$string['upcoming_for_course'] = 'Próximos eventos para este curso';
$string['no_course_events'] = 'No hay próximos eventos asignados a este curso.';
