<?php

// This file is part of Moodle - http://moodle.org/



defined('MOODLE_INTERNAL') || die();



$string['modulename'] = 'ZSK Termine zu diesem Kurs';

$string['modulenameplural'] = 'ZSK Termine zu diesem Kurs';

$string['pluginname'] = 'ZSK Termine zu diesem Kurs';

$string['modulename_help'] = 'Zeigt alle kommenden Termine an, die in der zentralen Terminverwaltung diesem Kurs zugeordnet wurden. Übergreifende Termine (ohne Kurs) werden hier nicht angezeigt.';

$string['zsktermine:addinstance'] = 'Aktivität „ZSK Termine zu diesem Kurs“ hinzufügen';

$string['zsktermine:view'] = 'Kurstermine ansehen';



$string['courseevents_info'] = 'Die diesem Kurs zugeordneten Termine werden direkt auf der Kursseite unter der Aktivität angezeigt (ohne Klick). Optional können Sie zusätzlich eine Beschreibung einblenden.';

$string['upcoming_for_course'] = 'Kommende Termine in diesem Kurs';

$string['no_course_events'] = 'Für diesen Kurs sind derzeit keine kommenden Termine eingetragen.';

