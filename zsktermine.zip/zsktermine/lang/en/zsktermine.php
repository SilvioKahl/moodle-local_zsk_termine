<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

defined('MOODLE_INTERNAL') || die();



$string['modulename'] = 'ZSK course events';

$string['modulenameplural'] = 'ZSK course events';

$string['pluginname'] = 'ZSK course events';

$string['modulename_help'] = 'Shows upcoming events assigned to this course in the central events manager. Site-wide events (no course) are not shown here.';

$string['zsktermine:addinstance'] = 'Add a “ZSK course events” activity';

$string['zsktermine:view'] = 'View course events';



$string['courseevents_info'] = 'Events assigned to this course are shown directly on the course page below the activity (no click required). You can optionally show an introduction as well.';

$string['upcoming_for_course'] = 'Upcoming events for this course';

$string['no_course_events'] = 'There are no upcoming events assigned to this course.';

$string['privacy:metadata'] = 'The ZSK course events activity stores only course module configuration and no personal data.';

