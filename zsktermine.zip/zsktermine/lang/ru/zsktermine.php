<?php

// This file is part of Moodle - http://moodle.org/



defined('MOODLE_INTERNAL') || die();



$string['modulename'] = 'Мероприятия курса ZSK';
$string['modulenameplural'] = 'Мероприятия курса ZSK';
$string['pluginname'] = 'Мероприятия курса ZSK';
$string['modulename_help'] = 'Показывает предстоящие события, назначенные этому курсу, в центральном менеджере событий. События, охватывающие весь сайт (без курса), здесь не показаны.';
$string['zsktermine:addinstance'] = 'Добавьте действие «Мероприятия курса ZSK»';
$string['zsktermine:view'] = 'Посмотреть мероприятия курса';
$string['courseevents_info'] = 'События, назначенные этому курсу, отображаются непосредственно на странице курса под действием (щелкнуть мышью не требуется). При желании вы также можете показать введение.';
$string['upcoming_for_course'] = 'Ближайшие события этого курса';
$string['no_course_events'] = 'Для этого курса нет предстоящих мероприятий.';
