<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$callbacks = [];

if (class_exists(\core\hook\output\before_standard_head_html_generation::class)) {
    $callbacks[] = [
        'hook' => \core\hook\output\before_standard_head_html_generation::class,
        'callback' => [\mod_zsktermine\hook_callbacks::class, 'load_styles_on_course'],
    ];
}
