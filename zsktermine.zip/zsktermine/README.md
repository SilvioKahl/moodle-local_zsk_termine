# ZSK Termine – course activity (`mod_zsktermine`)

Course activity that lists upcoming events assigned to the current course (from the central event store in **`local_zsk_termine`**).

**Product description (both plugins):** [`../local/zsk_termine/docs/de/Beschreibung.md`](../local/zsk_termine/docs/de/Beschreibung.md) · [English](../local/zsk_termine/docs/en/Beschreibung.md)

## Requirements

- **`local_zsk_termine`** (required)
- Moodle 4.1+

## Installation (Kurz)

**Vollständige Anleitung:** [`local/zsk_termine/docs/de/INSTALLATION_ADMIN.md`](local/zsk_termine/docs/de/INSTALLATION_ADMIN.md)

1. Install **`local_zsk_termine`** first.
2. Copy the folder `zsktermine` into `moodle/mod/`.
3. Open **Site administration → Notifications** and complete the upgrade.

> **Note:** Activity module folder names must not contain underscores (Moodle core rule). The component is `mod_zsktermine`, not `mod_zsk_termine`.

## Moodle.org short description

> Course activity “Course events”. Displays course-specific upcoming events from **`local_zsk_termine`**. Install the local plugin first.

moodle.org-Texte (DE/EN): [`docs/MOODLE_ORG_TERMINE.md`](../../docs/MOODLE_ORG_TERMINE.md)

## Migration

See `local/zsk_termine/docs/MIGRATION.md`.
